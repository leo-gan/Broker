﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Broker
{
    public class Processor 
    {
        /// <summary>
        /// It downloads the mapping definition from a config file.
        /// </summary>
        public Processor()
        {
            
        }
        /// <summary>
        /// It extract a control point name from the CIP message.
        /// It should be in the /Integration/ControlPoint/text() xpath.
        /// </summary>
        /// <param name="msg">CIP message as an XDocument</param>
        /// <returns></returns>
        public static string GetOperation(XDocument msg)
        {
            return msg.Descendants(XName.Get("ControlPoint")).First().Value;
        }

        public static IEnumerable<CallRequest> CreateCallerRequests(XDocument msg, string op)
        {

            // 
            return new List<CallRequest>();
        }
    }
}