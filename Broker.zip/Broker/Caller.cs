﻿namespace Broker
{
    internal class Caller {
        public static void Call(string callAddress, object request, object callerRequest)
        {
            throw new System.NotImplementedException();
        }
    }
}