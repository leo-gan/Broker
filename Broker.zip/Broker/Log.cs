﻿using System;

namespace Broker
{
    internal class Log {
        public Log(string logAddress)
        {
            throw new NotImplementedException();
        }

        public  void CreateConditionalReport(DateTime lastLogReportTimestamp, TimeSpan intervalBetweenReports)
        {
            throw new NotImplementedException();
        }
    }
}