﻿using System;
using System.Collections;
using System.Threading;
using System.Xml.Linq;

namespace Broker
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var config = new Config();
            config.Initialize(); // config.WriteFiles(); // degugg
            //Program.Loop(config);
        }

        public static void Loop(Config config)
        {
            var log = new Log(config.LogAddress);
            while (true) // infinite loop
            {
                var msg = FileManager.GetMessage(config.InputEndpointAddress);
                if (msg != null)
                {
                    var op = Processor.GetOperation(msg.Item2);
                    var callerRequests = Processor.CreateCallerRequests(msg.Item2, op); // 1-M cardinality for op-call
                    foreach (var callerRequest in callerRequests)
                        foreach (var callAddress in config.CallAddresses[op])
                            Caller.Call(callAddress, callerRequest, log);
                    FileManager.ArchiveMessage(config.InputEndpointAddress, config.ArchiveAddress, msg.Item1);
                }
                else // no new message found
                    Thread.Sleep(config.ListenCycleDelay_msec);
                log.CreateConditionalReport(config.LastLogReportTimestamp, config.IntervalBetweenReports);
            }
        }

    }
}