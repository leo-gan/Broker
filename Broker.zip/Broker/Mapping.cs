﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Broker
{
    /// <summary>
    /// It defines 1 to M mapping from Odyssey (Source) to ISAB (Target)
    /// </summary>
    public class Mapping
    {
        /// <summary>
        /// Now it is the Odyssey Control Point as "SAVE-CR-CASE"
        /// </summary>
        public string Source { get; set; }
        /// <summary>
        /// Now it is a name of interface as PetionAddUpdate. 
        /// I assume it is an endpoint name in a Cloverleaf web-service.
        /// There could be several such names related to a single Odyssey Control Point. 
        /// This relation defined as several Mapping objects.
        /// </summary>
        public string Target { get; set; }

        /// <summary>
        /// Important! Here is it the reverse mapping (sort of), Key is a target not a source.
        /// Key: It is a name of the field in the ISAB database as it appears in documentation.
        /// An example: fj_petn_cno
        /// Value: It is an XPath expression applied to the Odyssey CIP package message. 
        /// An example: /Integration/Case/CaseNumber
        /// </summary>
        public Dictionary<string, string> Fields { get; set; }
    }
    ///// <summary>
    ///// It defines a mapping between a value in Odyssey and a value in the ISAB system
    ///// </summary>
    //public class Fields
    //{
    //    /// <summary>
    //    /// It is an XPath expression applied to the Odyssey CIP package message. 
    //    /// An example: /Integration/Case/CaseNumber
    //    /// </summary>
    //    public string Source { get; set; }
    //    /// <summary>
    //    /// It is a name of the field in the ISAB database as it appears in documentation.
    //    /// An example: fj_petn_cno
    //    /// </summary>
    //    public string Target { get; set; }
    //}
}
