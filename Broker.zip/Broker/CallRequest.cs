﻿using System;
using System.Collections.Generic;

namespace Broker
{
    [Serializable]
    public class CallRequest
    {
        public string Operation { get; set; }
        public IEnumerable<Field> Fields { get; set; }
    }

    [Serializable]
    public class Field
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public Action Action { get; set; }
    }

    [Serializable]
    public enum Action
    {
        A,
        E,
        D
    }
}