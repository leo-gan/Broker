﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Broker.Test
{
    [TestFixture]
    public class ProcessorTest
    {
        private static string sampleDir = @"C:\Projects\CMS\Integration\JubDelq\Apps\Broker\Broker.Test\Samples\";
        private static string EmptyDir = sampleDir + "Empty";
        private static string DoNotChangeDir = sampleDir + "DoNotChange";
        private static string InputDir = sampleDir + "Input";
        private static string ArchiveDir = sampleDir + "Archive";
        private static string oldestFile = @"Tst-SAVE-CR_All_SAVE-CR-CASE_16LJJD00005A_lganeline-2016-07-11T16-16-37-130.xml";
        [Test]
        public void GetOperation()
        {
            var msg = FileManager.GetMessage(DoNotChangeDir); // get any message
            var op = Processor.GetOperation(msg.Item2);
            Assert.IsNotNullOrEmpty(op);
            Console.WriteLine(op);
        }
    }
}
